package com.mycompany.blackjack;

/**
 *
 * @author javeed Sali & Jaames & Shaileshbhai Vaghela
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Hand {

    private String playerName;
    private String dealerName;

    public Hand(String playerName, String dealerName) {
        this.playerName = playerName;
        this.dealerName = dealerName;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getDealerName() {
        return dealerName;
    }

    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    public String hitOrStay() {
        Scanner input = new Scanner(System.in);
        String answer;
        System.out.print(playerName + ", please choose to 'Hit' or 'Stay': ");
        answer = input.next();
        if (answer.startsWith("H") || answer.startsWith("h")) {
            return "hit";
        } else if (answer.startsWith("S") || answer.startsWith("s")) {
            return "stay";
        } else {
            return "null";
        }
    }

    public int totalScore(ArrayList<Card> hand) {
        Card currentCard;
        int currentCardValue = 0;
        int total = 0;
        for (Card eachCard : hand) {
            int cardValue = eachCard.getValue();
            if (cardValue == 1) {
                total = total + 11;
            } else {
                total = total + cardValue;
            }
        }
        if (total > 21) {
            for (int i = 0; i < hand.size(); i++) {
                currentCard = hand.get(i);
                currentCardValue = currentCard.getValue();
                if (currentCardValue == 1) {
                    total = total - 10;
                    return total;
                }
            }
        }
        return total;
    }

    public String gameStatus(int score, int totalCards, String name) {
        for (int i = 1; i <= 5; i++) {
            if (score >= 21) {
                if (score > 21) {
                    return "Bust";
                } else {
                    return "Win";
                }
            }
            if (!(name.equals("Dealer"))) {
                if (totalCards == 5) {
                    return "Charlie";
                }
            }
        }
        return "Continue";
    }

    public String isWin(String playerStatus, String dealerStatus, int dealerScore, int playerScore) {
        if (!(playerStatus.equals("Bust")) && !(dealerStatus.equals("Bust"))) {
            if (playerScore > dealerScore) {
                return "The winner is " + getPlayerName();
            } else if (playerScore < dealerScore) {
                return "The winner is " + getDealerName();
            } else {
                return "It's a draw!";
            }
        } else if (playerStatus.equals("Bust")) {
            return getPlayerName() + " Busts! " + getDealerName() + " won!";
        } else {
            return getDealerName() + " Busts! " + getPlayerName() + " won!";
        }
    }
}
