package com.mycompany.blackjack;


/**
 *
 * @author javeed Sali & Jaames & Shaileshbhai Vaghela
 */

import java.util.Random;
import java.util.ArrayList;

public class DeckOfCards {

    private ArrayList<Card> DeckOfCards;

    public DeckOfCards() {
        int[] CardValuesList = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10};
        DeckOfCards = new ArrayList<Card>();
        for (int cardNumber : CardValuesList) {
            Card currentCard = new Card(cardNumber);
            for (int j = 1; j <= 4; j++) {
                DeckOfCards.add(currentCard);
            }
        }
    }

    public Random random() {
        Random random = new Random();
        return random;
    }

    public int getDeckSize() {
        return DeckOfCards.size();
    }

    public Card getRandomCard() {
        int index = random().nextInt(getDeckSize());
        Card randomCard = DeckOfCards.get(index);
        return randomCard;
    }

    public void shuffleDeck() {
        for (int i = 0; i < getDeckSize(); i++) {
            Card randomCard = getRandomCard();
            int randomCardIndex = DeckOfCards.indexOf(randomCard);
            DeckOfCards.remove(randomCardIndex);
            DeckOfCards.add(randomCard);
        }
    }

    public Card dealCard() {
        Card randomCard = getRandomCard();
        int randomCardIndex = DeckOfCards.indexOf(randomCard);
        DeckOfCards.remove(randomCardIndex);
        return randomCard;
    }

    public ArrayList<Card> getDeck() {
        return DeckOfCards;
    }

    public void setDeck(ArrayList<Card> DeckOfCards) {
        this.DeckOfCards = DeckOfCards;
    }

    public void initialDraw(String name, Card card) {
        System.out.println(name + " draws " + card + ".");
    }

    @Override
    public String toString() {
        return "Current deck of cards: " + "\n" + getDeck();
    }
}
