package com.mycompany.blackjack;

/**
 *
 * @author javeed Sali & Jaames & Shaileshbhai Vaghela
 */
public class Dealer extends PlayersHand{
	
	
	private String dealerName;
	
	public Dealer(){
		
		
		super();
		 
		dealerName = "Dealer";
					
	}
			
	public String getName(){
		
		return dealerName;
		
	}//end method getName
	
	
	public void setName(String dealerName){
		
		this.dealerName = dealerName;
	}
	
	public boolean dealerTurn(int dealerScore, int playerScore){
		
		
		if(dealerScore < playerScore){
			
			return true;
			
		}
		else{
			return false;
			
			}//end else
		
	}
	public boolean dealerAI(int dealerScore, int playerScore, String playerStays){
		
		
		if (dealerScore == 21){
			
			return false;
		}
		else if (playerScore > 21){
			
			return false;
		}
		else if(playerScore < dealerScore){
				
			if (dealerScore >= 17){
				
				return false;
			}
				
		}//end else if
		
		
		else if (playerStays.equals("stay")){
			
			if(dealerScore > playerScore){
				
				return false;
			}//end if 
		}
		return true;
				
	}
	public String toString(){
			
		return getName() + "'s card hand is: " + super.toString();
	}//end method toString
		
		

}