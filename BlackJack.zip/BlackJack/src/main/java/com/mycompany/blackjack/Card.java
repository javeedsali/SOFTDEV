package com.mycompany.blackjack;

/**
 *
 * @author javeed Sali & Jaames & Shaileshbhai Vaghela
 */
public class Card {

    private int value;

    public Card(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return getValue() + "";
    }
}
