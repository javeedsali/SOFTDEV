/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.blackjack;

import java.util.ArrayList;

/**
 *
 * @author javeed Sali & Jaames & Shaileshbhai Vaghela
 */
//start of parent class
public class PlayersHand {
	 
	private ArrayList < Card > hand;
	
	
	//Constructor
	public PlayersHand(){
		
		hand = new ArrayList< Card >();
		
	}
	public void setHand( ArrayList< Card > hand){
		
		this.hand = hand;
	}
	public ArrayList< Card > getHand(){
		return hand;
	}
	public void addCard(Card card){
		
		hand.add(card);	
	}
	public int getNumOfCards(){
		
		
		int totalCards = 0;
		
		for (Card eachCard: hand){
			
			
			totalCards = totalCards + 1;
				
		}//end of for each loop
		
		return totalCards;
		
	}
		
	
	@Override 
	public String toString(){
		
		return getHand() + "";
		
	}
	
	
	

}