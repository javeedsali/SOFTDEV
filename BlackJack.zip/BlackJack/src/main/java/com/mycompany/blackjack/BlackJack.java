package com.mycompany.blackjack;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author javeed Sali & Jaames & Shaileshbhai Vaghela
 */
public class BlackJack {

    public static void main(String[] args) {
        do {
            Player player = new Player();
            ArrayList<Card> playerHand = player.getHand();
            int playerScore = 0;
            int playerTotalCards = 0;
            String playerStatus = "";

            Dealer dealer = new Dealer();
            ArrayList<Card> dealerHand = dealer.getHand();
            int dealerScore = 0;
            int dealerTotalCards = 0;
            String dealerStatus = "";

            Hand hand = new Hand(player.getName(), dealer.getName());
            String winnerOfGame = "";

            DeckOfCards deckOfCards = new DeckOfCards();
            deckOfCards.shuffleDeck();

            Card playerCard = deckOfCards.dealCard();
            player.addCard(playerCard);

            Card dealerCard = deckOfCards.dealCard();
            dealer.addCard(dealerCard);

            deckOfCards.initialDraw(player.getName(), playerCard);
            deckOfCards.initialDraw(dealer.getName(), dealerCard);

            String playerChoice = hand.hitOrStay();

            while (playerChoice.equals("hit")) {
                player.addCard(deckOfCards.dealCard());
                playerScore = hand.totalScore(playerHand);
                playerTotalCards = player.getNumOfCards();
                playerStatus = hand.gameStatus(playerScore, playerTotalCards, player.getName());

                System.out.println(player);
                System.out.println(player.getName() + "'s score is: " + playerScore);
                System.out.println(player.getName() + "'s status is: " + playerStatus + "\n");

                if (playerStatus.equals("Continue")) {
                    playerChoice = hand.hitOrStay();
                } else {
                    System.out.println(player.getName() + ", cannot draw anymore because your " +
                            "status is: " + playerStatus + "\n");
                    break;
                }
            }

            if (playerStatus.equals("Charlie")) {
                System.out.println("Charlie! Congrats, " + player.getName() + "! You won!");
            } else {
                dealerScore = hand.totalScore(dealerHand);

                while (dealer.dealerTurn(dealerScore, playerScore)) {
                    if (dealer.dealerAI(dealerScore, playerScore, playerChoice)) {
                        dealerScore = hand.totalScore(dealerHand);
                        dealerTotalCards = dealer.getNumOfCards();
                        dealerStatus = hand.gameStatus(dealerScore, dealerTotalCards, dealer.getName());

                        if (dealerStatus.equals("Continue")) {
                            dealer.addCard(deckOfCards.dealCard());
                        } else {
                            break;
                        }
                    } else {
                        break;
                    }
                }

                System.out.println(dealer.getName() + "'s turn is now over.\n");

                winnerOfGame = hand.isWin(playerStatus, dealerStatus, dealerScore, playerScore);

                System.out.println(player.getName() + "'s final score is: " + playerScore);
                System.out.println(player + "\n");
                System.out.println(dealer.getName() + "'s final score is: " + dealerScore);
                System.out.println(dealer);

                System.out.println("\n" + winnerOfGame + "\n");
            }
        } while (playAgain());
    }

    public static boolean playAgain() {
        Scanner playAgainInput = new Scanner(System.in);
        System.out.print("Enter the word 'yes' to play again, or anything else to end the game: ");
        String answer = playAgainInput.next();

        return answer.equalsIgnoreCase("yes");
    }
}
